java -cp $CLASSPATH:./testmq.jar testjava.MQManager put
java -cp $CLASSPATH:./testmq.jar testjava.MQManager get

