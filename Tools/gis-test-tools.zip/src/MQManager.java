package testjava;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.Properties;

import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;

/**
 * Simple example program
 */
public class MQManager {

	// code identifier
	static final String sccsid = "%Z% %W% %I% %E% %U%";

	private String qManager; 
	private String qName;

	private int max_msgs;
	private int max_secs;
	private int wait_empty_queue;
	private int curr_msgs;
	private MQQueueManager queueMgr;
	private MQQueue que;
	private boolean stoprun;
	private Timestamp starttime;
	private Timestamp currenttime;
	private String[] messages;
	private String filename;
	private Properties prop;

	public void readinitfile(String initfile) {
		try (InputStream input = new FileInputStream("/u/greefdn/MQmanager.properties")) {

            prop = new Properties();
            prop.load(input);
            // get the property value and print it out
            System.out.println(prop.getProperty("QMGR"));
            System.out.println(prop.getProperty("QUEUENAME"));
            
         } catch (IOException ex) {
            ex.printStackTrace(); 
        }
	}
	
	public void initMQmanager() {
		readinitfile("bla");
		qManager = prop.getProperty("QMGR");
		qName = prop.getProperty("QUEUENAME");
		max_msgs = 1000;
		max_secs = 10;
		curr_msgs = 0;
		stoprun = false;
		starttime = new Timestamp(System.currentTimeMillis());
		messages = new String[max_msgs];
		wait_empty_queue = 5;

		try {
			System.out.println("Connecting to queue manager: " + qManager);
			queueMgr = new MQQueueManager(qManager);
			int openOptions = MQConstants.MQOO_INPUT_AS_Q_DEF | MQConstants.MQOO_OUTPUT;
			System.out.println("Accessing queue: " + qName);
			que = queueMgr.accessQueue(qName, openOptions);

		} catch (MQException ex) {
			System.out.println("An IBM MQ Error occurred : Completion Code " + ex.completionCode + " Reason Code "
					+ ex.reasonCode);
			ex.printStackTrace();
			for (Throwable t = ex.getCause(); t != null; t = t.getCause()) {
				System.out.println("... Caused by ");
				t.printStackTrace();
			}
		}
	}


	public void getmsg() {

		try {
			System.out.println("Connecting to queue manager: " + qManager);
			MQQueueManager qMgr = new MQQueueManager(qManager);
			int openOptions = MQConstants.MQOO_INPUT_AS_Q_DEF | MQConstants.MQOO_OUTPUT;
			System.out.println("Accessing queue: " + qName);
			MQQueue queue = qMgr.accessQueue(qName, openOptions);

			MQMessage rcvMessage = new MQMessage();

			MQGetMessageOptions gmo = new MQGetMessageOptions();
			System.out.println("Getting a message");
			queue.get(rcvMessage, gmo);

			String msgText = rcvMessage.readLine();
			System.out.println("The message is: " + msgText);

			System.out.println("Closing the queue");
			queue.close();
			System.out.println("Disconnecting from the Queue Manager");
			qMgr.disconnect();
			System.out.println("Done!");
		} catch (MQException ex) {
			int cc = ex.completionCode;
			int rc = ex.reasonCode;

			if ((cc == 2) && (rc == 2033)) {
				System.out.println("Queue is read empty");
			} else {
				System.out.println("An IBM MQ Error occurred : Completion Code " + ex.completionCode + " Reason Code "
						+ ex.reasonCode);
				ex.printStackTrace();
				for (Throwable t = ex.getCause(); t != null; t = t.getCause()) {
					System.out.println("... Caused by ");
					t.printStackTrace();
				}
			}

		} catch (java.io.IOException ex) {
			System.out.println("An IOException occurred whilst writing to the message buffer: " + ex);
		}
		return;
	}

	public void putmsg() {
		try {
			System.out.println("Connecting to queue manager: " + qManager);
			MQQueueManager qMgr = new MQQueueManager(qManager);
			int openOptions = MQConstants.MQOO_INPUT_AS_Q_DEF | MQConstants.MQOO_OUTPUT;
			System.out.println("Accessing queue: " + qName);
			MQQueue queue = qMgr.accessQueue(qName, openOptions);

			for (int i = 0; i < 30; i++) {
				MQMessage msg = new MQMessage();
				msg.writeString("Hello, World from putmsg #" + i);
				MQPutMessageOptions pmo = new MQPutMessageOptions();
				System.out.println("Sending a message...");
				queue.put(msg, pmo);
			}

			System.out.println("Disconnecting from the Queue Manager");
			qMgr.disconnect();
			System.out.println("Done!");
		} catch (MQException ex) {
			System.out.println("An IBM MQ Error occurred : Completion Code " + ex.completionCode + " Reason Code "
					+ ex.reasonCode);
			ex.printStackTrace();
			for (Throwable t = ex.getCause(); t != null; t = t.getCause()) {
				System.out.println("... Caused by ");
				t.printStackTrace();
			}

		} catch (java.io.IOException ex) {
			System.out.println("An IOException occurred whilst writing to the message buffer: " + ex);
		}
		return;
	}

	
	public void putget() {
		try {
			// Create a connection to the QueueManager
			System.out.println("Connecting to queue manager: " + qManager);
			MQQueueManager qMgr = new MQQueueManager(qManager);

			// Set up the options on the queue we wish to open
			int openOptions = MQConstants.MQOO_INPUT_AS_Q_DEF | MQConstants.MQOO_OUTPUT;

			// Now specify the queue that we wish to open and the open options
			System.out.println("Accessing queue: " + qName);
			MQQueue queue = qMgr.accessQueue(qName, openOptions);

			// Define a simple IBM MQ Message ...
			MQMessage msg = new MQMessage();
			// ... and write some text in UTF8 format
			msg.writeUTF("Hello, World!");

			// Specify the default put message options
			MQPutMessageOptions pmo = new MQPutMessageOptions();

			// Put the message to the queue
			System.out.println("Sending a message...");
			queue.put(msg, pmo);

			// Now get the message back again. First define an IBM MQ
			// message
			// to receive the data
			MQMessage rcvMessage = new MQMessage();

			// Specify default get message options
			MQGetMessageOptions gmo = new MQGetMessageOptions();

			// Get the message off the queue.
			System.out.println("...and getting the message back again");
			queue.get(rcvMessage, gmo);

			// And display the message text...
			String msgText = rcvMessage.readLine();
			System.out.println("The message is: " + msgText);

			// Close the queue
			System.out.println("Closing the queue");
			queue.close();

			// Disconnect from the QueueManager
			System.out.println("Disconnecting from the Queue Manager");
			qMgr.disconnect();
			System.out.println("Done!");
		} catch (MQException ex) {
			System.out.println("An IBM MQ Error occurred : Completion Code " + ex.completionCode + " Reason Code "
					+ ex.reasonCode);
			ex.printStackTrace();
			for (Throwable t = ex.getCause(); t != null; t = t.getCause()) {
				System.out.println("... Caused by ");
				t.printStackTrace();
			}

		} catch (java.io.IOException ex) {
			System.out.println("An IOException occurred whilst writing to the message buffer: " + ex);
		}
		return;
	}

	public static void main(String args[]) {
		MQManager za = new MQManager();
		za.initMQmanager();
		if (args[0].equals("get")) {
			za.getmsg();
		} else {
			if (args[0].equals("put")) {
				za.putmsg();
			} else {
				System.out.println("Give put or get as input");
			}
		}
		return;
	}
}
